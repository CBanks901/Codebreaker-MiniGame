#include <iostream>
#include <time.h>
#include <random>
#include <ostream>
#include <string>
#include <string.h>
#include <sstream>
#include <istream>
#include <stdio.h>
#include <conio.h>

using namespace std;

// Custom struct that contains all of the crucial information that we need for our game.
struct InfoStruct
{
	string codecopy, usercode;							// Codecopy is intended to be a string copy of the actual code, and usercode a copy of the users guess.
	int correctdigits, findindex;						// keycounter is for tracking input while entered, correctdigits is for number of correct digits, and findindex is for the 
														// string based on the actual code (will be used to determine if what the user entered is actually in the code)
	char userinput[4];									// array of 4 characters that the user will enter to guess the sequence.
	bool inputretry = false;							// Used at the end of the sequence or chances to determine if the player is going to retry or not
	bool validcode = false;
}; InfoStruct userinfo;									// Global instance is created here since this variable will be used in different functions

// This function simply generates the random code sequnece that will be determined. At a glance, the arguments (in order) are to the code pointer, the second is to the array of 
// numbers that will be used, and the last argument is for the size of that numberlist. 
void randomKeySelection(int *code, int listRef[], int sizeL)
{
	int selectioncounter = 0;																				// A counter for the current index of the secretcode
	bool usedCounter[10] = { false, false, false, false,false, false, false, false , false, false };		// If a number has been generated, the corresponding bool will be set to true
																											// to prevent that same number being used again.
	int randomness;																							// simply a integer holder that will store the random numbers

	// Loop that will generate the code in response to the selectioncounter variable (Maximum of 4 times).
	do
	{
		randomness = rand() % sizeL;								// Generate a random number centered around the sizeL argument, between 0 - 9;

		// Based on the randomness variable, if the value inside the usedCounter boolean is false, then proceed. Only inside this sequence will the selectioncounter be increased which
		// will stop the loop.
		// Inside the if statement, set the boolean based on that selected index to true to prevent this digit being used again, set the code based on selectioncounter to the listRef
		// argument that was passed in based on that index, finally increased the counter to proceed to break the loop.
		if (usedCounter[randomness] == false)
		{
			usedCounter[randomness] = true;
			code[selectioncounter] = listRef[randomness];
			++selectioncounter;
		}

	} while (selectioncounter < 4);

	//Finally simply set the codecopy string inside the userinfo struct to the full combination of our code by converting each digit of the code into a string.
	userinfo.codecopy = to_string(code[0]) + to_string(code[1]) + to_string(code[2]) + to_string(code[3]);

}

// This function handles the entire sequence of the game including input, retries and termination. Its arugments in order are the code array, the number of chances, and a repeat reference 
// variable which is used inside the main scope. If a repeat is requested, recursion is used, if not then the function simply ends and the main scope terminates the program.
void guessingSequence(int *secretcode, int chances, char &repeat)
{
	// Set the userinfo valid boolean to false so we can loop through 
	userinfo.validcode = false;

	string inputString("");
	// While the validcode boolean is set to false which it is on initial run through, keep asking for input. Will be broken when the user enters at least a 4 digit number
	do
	{
		cin >> inputString;
		
		// If the size that the user entered is equal to 4, then keep nesting down at least till the first 4 keys
		if (inputString.size() == 4)
		{
			if (isdigit(inputString[0]))
			{
				if (isdigit(inputString[1]))
				{
					if (isdigit(inputString[2]))
					{
						if (isdigit(inputString[3]))
						{
							userinfo.userinput[0] = inputString[0];
							userinfo.userinput[1] = inputString[1];
							userinfo.userinput[2] = inputString[2];
							userinfo.userinput[3] = inputString[3];
							userinfo.validcode = true;
							break;
						}
					}
				}
			}
		}
		
		cout << "Error, please eter a 4 digit code with numbers between 0 - 9" << endl;

	} while (!userinfo.validcode);

	// Simple for loop that basically replaces the code string (usercode) inside of our userinfo struct to the input based on the index of the loop
	for (int i = 0; i < 4; ++i)
		userinfo.usercode.replace(i, i + 1, 1, userinfo.userinput[i]);

	// Compare the string usercode inside the userinfo struct to the secret code inside the struct. If they are equal (0) then the code has been cracked. If not the following branch will
	// execute.
	if (userinfo.usercode.compare(userinfo.codecopy) == 0)
	{
		cout << "Code cracked!!" << endl;
	}
	else
	{
		// This section is for if 1 or more of the keys that the player entered is wrong. First the find index inside the struct is set to -1, and the correct digits integer is set to 0. 
		userinfo.findindex = -1;
		userinfo.correctdigits = 0;

		// Loop through the four characters that the player entered
		for (int j = 0; j < 4; j++)
		{
			// Set the findindex variable to the codecopy's attempt to find the digit that the user entered based on the for loop (in order).
			userinfo.findindex = userinfo.codecopy.find(userinfo.usercode[j]);

			// If the index is valid and not a no position value (if it has been found) inside the actual code
			if (userinfo.findindex != string::npos)
			{
				// If the findindex is a valid index, but it isn't equal to the current value in the loop, this means the digit exists inside the code but at the wrong place.
				// Simply tell the user that the digit is correct but not placed. The correctdigit value remains the same.
				if (userinfo.findindex != j)
					cout << "Correct digit " << userinfo.codecopy[userinfo.findindex] << " but at the wrong place." << endl;
				else
				{
					// If this happens that means that the digit the player entered is correct and it is in the correct spot in response to the actual code. Correct digit is increased.
					cout << "Successful digit entered!!!\n";
					userinfo.correctdigits++;
				}
			}
			else
				cout << "Wrong digit " << userinfo.userinput[j] << " entered" << endl;					// In this case the findindex is a no position which means that number doesn't
																										// exist in the code
		}

		cout << "Correct digits overall: " << userinfo.correctdigits << endl;

		// If the number of chances left is greater than 0, we simply use recursion to call this function again but we decrease the number of chances by 1. This will continue either 
		// until the code has been cracked, or the player runs out of chances all together. If they make it here again with no chances, it simply tells them that they have no chances
		// left.
		if (chances > 0)
		{
			cout << "Chance remaining " << chances << endl;
			return guessingSequence(secretcode, chances - 1, repeat);
		}
		else
			cout << "Sorry you are out of chances." << endl;
	}


	cout << "Would you like to continue? Y or N" << endl;

	// Set the input retry boolean inside the struct to false for the following section of the code
	userinfo.inputretry = false;

	// While the retry boolean is false, keep asking the player if they want to continue or not by pressing y, Y, n or N. Regardless set the inputretry bool to true to break this 
	// whil loop. If the input is something else, keep asking for a valid input over and over again.
	while (userinfo.inputretry == false)
	{
		repeat = _getch();
		if (repeat == 'y' || repeat == 'Y')
			userinfo.inputretry = true;
		else if (repeat == 'n' || repeat == 'N')
			userinfo.inputretry = true;
		else
			cout << "Please type y or n. \n";
	}
}

int main()
{
	srand(time(NULL));		// random time seed for randomness
	int numberlist[10] = { 0, 1, 2, 3, 4, 5, 6, 7 ,8 , 9 };		// array of numbers that will be used for references later
	int *secretcode = new int[4];								// dynamic pointer that will be used for secrete code until the end of the programs life cycle
	char repeat('y');											// a repeat character that is initialized to Y initially

	// Perform this loop while the repeat variable is equal to Y or y for yes. Repeat variable is changed inside the guessingSequence function
	do
	{
		randomKeySelection(secretcode, numberlist, size(numberlist));		// custom function that sets the secret code based on the numberlist array

		cout << "Welcome. You have 8 chances to guess the correct 4 digit code sequence." << endl;
		guessingSequence(secretcode, 7, repeat);							// This function asks the user to guess the code and handles all important brances such as continuations and failures
	} while (repeat == 'y' || repeat == 'Y');

	// This means the end. If the secretcode is not equal to NULL, destroy it and release the memory
	if (secretcode != NULL)
		delete secretcode;
}
